-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: teste
-- ------------------------------------------------------
-- Server version	5.6.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `cidade` varchar(50) DEFAULT NULL,
  `uf` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'HENRIQUE','FLORIANÓPOLIS','SC'),(2,'JOSÉ','FLORIANÓPOLIS','SC'),(3,'ROBERTA','SÃO JOSÉ','SC'),(4,'AMANDA','BLUMENAU','SC'),(5,'SÉRGIO','CRICIÚMA','SC'),(6,'CARLOS','BALNEÁRIO CAMBURIÚ','SC'),(7,'JOÃO','PORTO ALEGRE','RS'),(8,'BRUNA','BAGÉ','RS'),(9,'CAMILA','LAGEADO','RS'),(10,'BRUNO','CURITIBA','PR'),(11,'DANIEL','LONDRINA','PR'),(12,'FERNANDO','MARINGÁ','PR'),(13,'PRISCILA','SÃO PAULO','SP'),(14,'REBECA','SANTOS','SP'),(15,'KARINE','CORDEIRÓPOLIS','SP'),(16,'PEDRO','LIMEIRA','SP'),(17,'LUIZ','RIO DE JANEIRO','RJ'),(18,'GUILHERME','NITERÓI','RJ'),(19,'MAURÍCIO','RECIFE','PE'),(20,'RENATA','FORTALEZA','CE'),(21,'CRISTIANE','NATAL','RN');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidos` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `data_emissao` date NOT NULL,
  `cliente` int(11) NOT NULL,
  `valor_total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `fl_pedidos_clientes_idx` (`cliente`),
  CONSTRAINT `fl_pedidos_clientes` FOREIGN KEY (`cliente`) REFERENCES `clientes` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` VALUES (1,'2021-07-07',1,34.99),(2,'2021-07-07',2,214.99),(3,'2021-07-07',4,700.00),(8,'2021-07-07',1,34.99),(10,'2021-07-08',2,34.99),(11,'2021-07-08',4,848.00),(12,'2021-07-08',18,1120.00),(13,'2021-07-08',14,679.80),(14,'2021-07-08',21,548.88),(16,'2021-07-08',12,6654.95);
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos_produtos`
--

DROP TABLE IF EXISTS `pedidos_produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidos_produtos` (
  `codigo` int(11) NOT NULL,
  `sequencia` int(11) NOT NULL,
  `produto` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `valor_unitario` decimal(10,2) NOT NULL,
  `valor_total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`codigo`,`sequencia`),
  KEY `fk_pedidosprodutos_produtos_idx` (`produto`),
  CONSTRAINT `fk_pedidosprodutos_produtos` FOREIGN KEY (`produto`) REFERENCES `produtos` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pedidosprodutos_pedidos` FOREIGN KEY (`codigo`) REFERENCES `pedidos` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos_produtos`
--

LOCK TABLES `pedidos_produtos` WRITE;
/*!40000 ALTER TABLE `pedidos_produtos` DISABLE KEYS */;
INSERT INTO `pedidos_produtos` VALUES (1,1,1,1,34.99,34.99),(2,1,1,1,34.99,34.99),(2,2,2,1,80.00,80.00),(2,3,3,1,100.00,100.00),(3,1,4,1,700.00,700.00),(8,1,1,1,34.99,34.99),(10,3,1,1,34.99,34.99),(11,1,20,1,8.00,8.00),(11,2,11,1,320.00,320.00),(11,3,15,1,520.00,520.00),(12,1,16,2,400.00,400.00),(12,2,15,1,520.00,520.00),(12,3,16,1,200.00,200.00),(13,1,5,2,600.00,600.00),(13,2,18,2,79.80,79.80),(14,1,14,1,489.00,489.00),(14,2,18,1,39.90,39.90),(14,3,9,1,19.98,19.98),(16,1,13,5,1500.00,1500.00),(16,2,7,1,149.99,149.99),(16,3,2,1,80.00,80.00),(16,4,8,1,85.00,85.00),(16,5,9,2,39.96,39.96),(16,6,11,15,4800.00,4800.00);
/*!40000 ALTER TABLE `pedidos_produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produtos` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(100) NOT NULL,
  `preco_venda` decimal(10,2) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,'PEN DRIVE',34.99),(2,'MOUSE',80.00),(3,'TECLADO',100.00),(4,'MONITOR',700.00),(5,'GABINETE',300.00),(6,'NOTEBOOK',4.20),(7,'WEBCAM',149.99),(8,'MICROFONE',85.00),(9,'FONE DE OUVIDO',19.98),(10,'PROCESSADOR',480.00),(11,'MEMÓRIA RAM',320.00),(12,'HD',290.00),(13,'SSD',300.00),(14,'PLACA MÃE',489.00),(15,'PLACA DE VÍDEO',520.00),(16,'PLACA DE SOM',200.00),(17,'PLACA DE REDE',55.00),(18,'ADAPTADOR WIFI',39.90),(19,'SUPORTE MONITOR',45.00),(20,'MOUSE PAD',8.00),(21,'CARREGADOR BATERIA NOTEBOOK',185.00);
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-08 13:33:51
